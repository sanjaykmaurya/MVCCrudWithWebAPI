﻿using Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace DataAccessLayer
{
   public class ClsDataAccess
    {
        public SqlConnection SqlCon = null;
        SqlCommand com;
        SqlConnection sqlcon;
        private SqlTransaction csplTrans;
        public DataTable SelectQuery(string StrQry)
        {
            DataTable dt = new DataTable();
            SqlDataAdapter da = default(SqlDataAdapter);
            CreateConnection();
            if (SqlCon.State == ConnectionState.Closed)
                SqlCon.Open();
            da = new SqlDataAdapter(StrQry, SqlCon);
            da.Fill(dt);
            SqlCon.Close();
            return dt;
        }
        public void CreateConnection()
        {
            SqlCon = new SqlConnection(WebConfigHelper.WPSDbConnection);
        }
        public void CloseConn()
        {
            if (sqlcon != null)
            {
                if (sqlcon.State == ConnectionState.Open)
                    sqlcon.Close();
            }

        }
        public void disposeConn()
        {
            if (sqlcon != null)
            {
                if (sqlcon.State == ConnectionState.Closed)
                    sqlcon.Dispose();
                sqlcon = null;
            }
        }
        public void OpenTransaction()
        {
            if (csplTrans != null)
            {
                csplTrans = null;
            }

            csplTrans = com.Connection.BeginTransaction(IsolationLevel.ReadCommitted, "Trans");
            com.Transaction = csplTrans;

        }


        public void CommintTransaction()
        {
            if (csplTrans != null)
            {
                csplTrans.Commit();
            }
        }

        public void RollbackTransaction()
        {
            if (csplTrans != null)
            {
                if (csplTrans.Connection != null)
                {
                    csplTrans.Rollback();
                }
            }
        }
        public int execStoredProcudure(string strProcName, SqlParameter[] arProcParams, string str)
        {
            Int32 returnValue;
            SqlTransaction sqltr;
            sqltr = null;
            SqlCommand cmd = new SqlCommand();
            try
            {
                CreateConnection();
                cmd.Connection = SqlCon;
                if (SqlCon.State == ConnectionState.Closed)
                {
                    SqlCon.Open();
                }
                sqltr = cmd.Connection.BeginTransaction();
                cmd.CommandTimeout = 10000000;
                cmd.Transaction = sqltr;
                SqlParameter param = new SqlParameter();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = strProcName;
                cmd.Parameters.Clear();
                foreach (SqlParameter LoopVar_param in arProcParams)
                {
                    param = LoopVar_param;
                    cmd.Parameters.Add(param);
                }
                returnValue = Convert.ToInt32(cmd.ExecuteNonQuery());
                sqltr.Commit();
                SqlCon.Close();
                return returnValue;

            }

            catch (SqlException ex)
            {
                if (ex.Number == 2627)
                {
                    sqltr.Rollback();
                    return 0;
                }
                else
                {
                    return 0;
                }
            }
            catch (DataException ex)
            {
                sqltr.Rollback();
                return 0;
            }
            catch (Exception ex)
            {
                sqltr.Rollback();
                return 0;

            }

        }
        public DataSet getDataTable(string StoreProc, SqlParameter[] arProcParams)
        {
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();
            try
            {
                SqlParameter param = new SqlParameter();
                CreateConnection();
                SqlDataAdapter da = new SqlDataAdapter();
                SqlCommand cmd = new SqlCommand(StoreProc, SqlCon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = StoreProc;
                cmd.Parameters.Clear();
                da.SelectCommand = cmd;
                foreach (SqlParameter LoopVar_param in arProcParams)
                {
                    param = LoopVar_param;
                    cmd.Parameters.Add(param);
                }
                da.Fill(ds);
                this.CloseConn();
                this.disposeConn();
                return ds;
            } catch (Exception ex)
            { 
            
            }
            return ds;


        }


    }
}
