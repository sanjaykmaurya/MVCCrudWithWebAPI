using System.Configuration;

namespace Common
{
    public class WebConfigHelper
    {
        public static string WPSDbConnection
        {
            get
            {
                return ConfigurationManager.ConnectionStrings["dbConnectionString"].ConnectionString;                
            }
        }
        public static string CSVconnection
        {
            get
            {
                return ConfigurationManager.ConnectionStrings["dbConnectionString"].ConnectionString;
            }
        }
    }
}
