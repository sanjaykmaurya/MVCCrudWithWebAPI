﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using DataAccessLayer;

namespace EmployeeManagement.Models
{
    public class BusinessLayer
    {
        private readonly ClsDataAccess dataAccessLayer;
        public BusinessLayer()
        {
            dataAccessLayer = new ClsDataAccess();
        }
        public List<EmployeeModel> GetAllEmployee()
        {
            DataSet DS = new DataSet();
            List<EmployeeModel> employeeModels = new List<EmployeeModel>();
            DataAccessLayer.ClsDataAccess obj = new DataAccessLayer.ClsDataAccess();
            SqlParameter[] sqlParam ={
                                              new SqlParameter("@QueryType","select")
                                          };
            DS = dataAccessLayer.getDataTable("SP_CRUD_Employee", sqlParam);
            if(DS.Tables.Count>0)
            {
                foreach (DataRow dr in DS.Tables[0].Rows)
                {
                    EmployeeModel employeeModel = new EmployeeModel();
                    employeeModel.EmployeeID = Convert.ToString(dr["EmployeeID"]);
                    employeeModel.EmployeeName = Convert.ToString(dr["EmployeeName"]);
                    employeeModel.Gender = Convert.ToString(dr["Gender"]);
                    employeeModel.Address = Convert.ToString(dr["Address"]);
                    employeeModel.Hobbies = Convert.ToString(dr["Hobbies"]);
                    employeeModel.StateName = Convert.ToString(dr["StateName"]);
                    employeeModel.DOB = Convert.ToDateTime(dr["DOB"]);

                    employeeModels.Add(employeeModel);
                }
            }
            
            
            return employeeModels;
        }
        public EmployeeModel GetEmployeeById(string employeeId)
        {
            DataTable dt = new DataTable();
            SqlParameter[] sqlParam ={
                                              new SqlParameter("@QueryType",""),
                                              new SqlParameter("@EmployeeId",employeeId)
                                          };
            dt = dataAccessLayer.getDataTable("SP_CRUD_Employee", sqlParam).Tables[0];
            EmployeeModel employeeModel = new EmployeeModel();
            if (dt.Rows.Count > 0)
            {
                employeeModel.EmployeeID = Convert.ToString(dt.Rows[0]["EmployeeID"]);
                employeeModel.EmployeeName = Convert.ToString(dt.Rows[0]["EmployeeName"]);
                employeeModel.Gender = Convert.ToString(dt.Rows[0]["Gender"]);
                employeeModel.Address = Convert.ToString(dt.Rows[0]["Address"]);
                employeeModel.Hobbies = Convert.ToString(dt.Rows[0]["Hobbies"]);
                employeeModel.StateId = Convert.ToInt32(dt.Rows[0]["StateId"]);
                employeeModel.DOB = Convert.ToDateTime(dt.Rows[0]["DOB"]);
            }

            return employeeModel;
        }
        public int SaveEmployee(EmployeeModel employeeModel)
        {
            SqlParameter[] sqlParam ={
                                              new SqlParameter("@QueryType","insert"),
                                              new SqlParameter("@EmployeeName",employeeModel.EmployeeName),
                                              new SqlParameter("@DOB",employeeModel.DOB),
                                              new SqlParameter("@Address",employeeModel.Address),
                                              new SqlParameter("@Hobbies",employeeModel.Hobbies),
                                              new SqlParameter("@Gender",employeeModel.Gender),
                                              new SqlParameter("@StateId",employeeModel.StateId)
                                          };
            return dataAccessLayer.execStoredProcudure("SP_CRUD_Employee", sqlParam,"");
        }
        public int UpdateEmployee(EmployeeModel employeeModel)
        {
            SqlParameter[] sqlParam ={
                                              new SqlParameter("@QueryType","update"),
                                              new SqlParameter("@EmployeeID",employeeModel.EmployeeID),
                                              new SqlParameter("@EmployeeName",employeeModel.EmployeeName),
                                              new SqlParameter("@DOB",employeeModel.DOB),
                                              new SqlParameter("@Address",employeeModel.Address),
                                              new SqlParameter("@Hobbies",employeeModel.Hobbies),
                                              new SqlParameter("@Gender",employeeModel.Gender),
                                              new SqlParameter("@StateId",employeeModel.StateId)
                                          };
            return dataAccessLayer.execStoredProcudure("SP_CRUD_Employee", sqlParam, "");
        }
        public int DeleteEmployee(string employeeModel)
        {
            SqlParameter[] sqlParam ={
                                              new SqlParameter("@QueryType","delete"),
                                              new SqlParameter("@EmployeeID",employeeModel)
                                          };
            return dataAccessLayer.execStoredProcudure("SP_CRUD_Employee", sqlParam, "");
        }

        public List<State> GetAllState()
        {
            DataTable dt = new DataTable();
            SqlParameter[] sqlParam ={
                                              new SqlParameter("@QueryType","states"),
                                          };
            dt = dataAccessLayer.getDataTable("SP_CRUD_Employee", sqlParam).Tables[0];
            List<State> states = new List<State>();
            if(dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    State state = new State();
                    state.StateId = Convert.ToInt32(dr["StateId"]);
                    state.StateName = Convert.ToString(dr["StateName"]);

                    states.Add(state);
                }
            }
            return states;
        }
    }
}