﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Results;
using EmployeeManagement.Models;

namespace EmployeeManagement.Controllers
{
    public class EmployeeAPIController : ApiController
    {
        private readonly BusinessLayer businessLayer;
        public EmployeeAPIController()
        {
            businessLayer = new BusinessLayer();
        }
        /// <summary>
        /// To get all employee
        /// </summary>
        /// <returns></returns>
        [Route("api/EmployeeAPI/GetAllEmployee")]
        [HttpGet]
        public IHttpActionResult GetAllEmployee()
        {
           var employeeList = businessLayer.GetAllEmployee();
            return Json(new { IsSuccess = true, data = employeeList });
        }
        /// <summary>
        /// To get employee based on employee id.
        /// </summary>
        /// <param name="employeeId"></param>
        /// <returns></returns>
        [Route("api/EmployeeAPI/GetEmployeeById/{employeeId}")]
        [HttpGet]
        public IHttpActionResult GetEmployeeById(string employeeId)
        {
            var employee = businessLayer.GetEmployeeById(employeeId);
            return Json(new { IsSuccess = true, data = employee });
        }

        /// <summary>
        /// To delete employee based on employee id.
        /// </summary>
        /// <param name="employeeId"></param>
        /// <returns></returns>
        [Route("api/EmployeeAPI/DeleteEmployee/{employeeId}")]
        [HttpPost]
        public IHttpActionResult DeleteEmployee(string employeeId)
        {
            var returnValue = businessLayer.DeleteEmployee(employeeId);
            return Json(new { IsSuccess = true, data = returnValue });
        }

        /// <summary>
        /// To Add new employee
        /// </summary>
        /// <param name="employeeModel"></param>
        /// <returns></returns>
        [Route("api/EmployeeAPI/SaveEmployee")]
        [HttpPost]
        public IHttpActionResult SaveEmployee(EmployeeModel employeeModel)
        {
            var returnValue = businessLayer.SaveEmployee(employeeModel);
            return Json(new { IsSuccess = true, data = returnValue });
        }

        /// <summary>
        /// To update employee
        /// </summary>
        /// <param name="employeeModel"></param>
        /// <returns></returns>
        [Route("api/EmployeeAPI/UpdateEmployee")]
        [HttpPost]
        public IHttpActionResult UpdateEmployee(EmployeeModel employeeModel)
        {
            var returnValue = businessLayer.UpdateEmployee(employeeModel);
            return Json(new { IsSuccess = true, data = returnValue });
        }

        /// <summary>
        /// To bind state dropdown
        /// </summary>
        /// <returns></returns>
        [Route("api/EmployeeAPI/GetAllState")]
        [HttpGet]
        public IHttpActionResult GetAllState()
        {
            var allState = businessLayer.GetAllState();
            return Json(new { IsSuccess = true, data = allState });
        }

    }
}
