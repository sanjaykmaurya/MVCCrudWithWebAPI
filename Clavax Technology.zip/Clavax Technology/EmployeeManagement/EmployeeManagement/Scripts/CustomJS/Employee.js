﻿var oTable = null;
$(document).ready(function () {
    BindEmployeeDetails();
    $('#btnsubmit').on('click', function (e) {
        e.preventDefault();
        if (validate()) {
            SaveEmployee();
        }
    });

    $('#btnUpdate').on('click', function (e) {
        e.preventDefault();
        if (EditValidate()) {
            UpdateEmployee();
        }
    });
    GetAllState();
});
function ViewUser(USER_ID) {
}
function EditEmployee(Employeeid) {
    $.ajax({
        url: "/api/EmployeeAPI/GetEmployeeById/" + Employeeid,
        type: 'get',
        dataType: "json",
        contentType: 'application/json',
        async: false,
        success: function (res) {
            if (res.IsSuccess) {
                $("#hdnEmployeeID").val(res.data.EmployeeID);
                $("#EEmployeeName").val(res.data.EmployeeName);
                $("#EDOB").val(res.data.DOB.split('T')[0]);
                $('#Editform').find(':radio[name=EGender][value="' + res.data.Gender + '"]').prop('checked', true);
                $("#EAddress").val(res.data.Address);
                $("#EStateId").val(res.data.StateId);
                var hobbies = res.data.Hobbies;
                if (hobbies.includes(',')){
                    hobbies = hobbies.split(',');
                    for (var i = 0; i < hobbies.length; i++) {
                        $('#Editform').find('input[type=checkbox][name="' + hobbies[i] + '"]').prop('checked', true);
                    }
                } else {
                    $('#Editform').find('input[type=checkbox][name="' + hobbies + '"]').prop('checked', true);
                }

                $('#AddForm').hide();
                $('#EditForm').show();
                $('#Details').hide();
            }
            else {

            }
        },
        error: function (err) {
            console.log(err);
        }

    });
}
function DeleteEmployee(Employeeid) {
    $.ajax({
        url: "/api/EmployeeAPI/DeleteEmployee/" + Employeeid,
        type: 'post',
        dataType: "json",
        contentType: 'application/json',

        success: function (res) {
            if (res.IsSuccess) {
                BindEmployeeDetails();
            }
            else {

            }
        },
        error: function (err) {
            console.log(err);
        }

    });
}
function BindEmployeeDetails() {
    debugger;
    $('#AddForm').hide();
    $('#EditForm').hide();
    $('#Details').show();
    //var oTable = null;
    oTable = null;
    // $('#UserDetails').empty();
    oTable = $('#EmployeeDetails').DataTable({
        "paging": true,
        "lengthChange": true,
        "fixedHeader": false,
        "searching": true,
        "ordering": true,
        "info": true,
        "autoWidth": false,
        "responsive": true,
        "destroy": true,
        "ajax": {
            "url": '/api/EmployeeAPI/GetAllEmployee',
            "type": "get",
            "datatype": "json"
        },
        "columns": [

            { "data": "EmployeeID", "autoWidth": true },
            { "data": "EmployeeName", "autoWidth": true },
            {
                "data": "DOB", "autoWidth": true,
                "render": function (data) {
                    return data.split('T')[0];

                }
            },
            { "data": "Gender", "autoWidth": true },
            { "data": "Address", "autoWidth": true },
            { "data": "StateName", "autoWidth": true },
            { "data": "Hobbies", "autoWidth": true },
            {
                "data": "EmployeeID", "width": "50px", "render": function (data) {
                    return "<a class='btn btn-info' onclick=EditEmployee('" + data + "')>Edit</a>";

                }
            },
            {
                "data": "EmployeeID", "width": "50px", "render": function (data) {

                    return "<a class='btn btn-danger' onclick=DeleteEmployee('" + data + "')>Delete</a>";

                }
            }
        ]
    })

}
function ShowAddUser() {
    $('#AddForm').show();
    $('#EditForm').hide();
    $('#Details').hide();
}
function Clear() {
    alert('clear');
}
function validate() {
    var EmployeeName = $("#EmployeeName").val();
    var DOB = $("#DOB").val();
    var Address = $("#Address").val();
    var StateId = $("#StateId").val();
    var Gender = $('input[name="Gender"]:checked').val();

    if (EmployeeName == "" || DOB == "" || Gender == "" || Address == "" || StateId == "") {
        alert("Please fill out this field");
        return false;
    }
    return true;
}
function EditValidate() {
    var EmployeeName = $("#EEmployeeName").val();
    var DOB = $("#EDOB").val();
    var Address = $("#EAddress").val();
    var StateId = $("#EStateId").val();
    var Gender = $('input[name="EGender"]:checked').val();

    if (EmployeeName == "" || DOB == "" || Gender == "" || Address == "" || StateId == "") {
        alert("Please fill out this field");
        return false;
    }
    return true;
}
function SaveEmployee() {
    var EmployeeName = $("#EmployeeName").val();
    var DOB = $("#DOB").val();
    var Address = $("#Address").val();
    var StateId = $("#StateId").val();
    var Gender = $('input[name="Gender"]:checked').val();
    var hobbies = $('input:checkbox:checked').map(function () {
        return this.value;
    }).get().join(",");

    const obj = {
        EmployeeName: EmployeeName,
        DOB: DOB,
        Gender: Gender,
        Address: Address,
        StateId: StateId,
        Hobbies: hobbies
    }

    $.ajax({
        url: "/api/EmployeeAPI/SaveEmployee",
        type: 'post',
        dataType: "json",
        contentType: 'application/json',
        data: JSON.stringify(obj),
        success: function (res) {
            if (res.IsSuccess) {
                BindEmployeeDetails();
            }
            else {

            }
        },
        error: function (err) {
            console.log(err);
        }

    });
}
function UpdateEmployee() {
    debugger
    var EmployeeId = $("#hdnEmployeeID").val();
    var EmployeeName = $("#EEmployeeName").val();
    var DOB=$("#EDOB").val();
    var Address= $("#EAddress").val();
    var StateId = $("#EStateId").val();
    var Gender = $('input[name="EGender"]:checked').val();
    var hobbies = $('input:checkbox:checked').map(function () {
        return this.value;
    }).get().join(",");

    const obj = {
        EmployeeId: EmployeeId,
        EmployeeName: EmployeeName,
        DOB: DOB,
        Gender: Gender,
        Address: Address,
        StateId: StateId,
        Hobbies: hobbies
    }

    $.ajax({
        url: "/api/EmployeeAPI/UpdateEmployee",
        type: 'post',
        dataType: "json",
        contentType: 'application/json',
        data: JSON.stringify(obj),
        success: function (res) {
            if (res.IsSuccess) {
                BindEmployeeDetails();
            }
            else {

            }
        },
        error: function (err) {
            console.log(err);
        }

    });
}

function GetAllState() {
    $.ajax({
        url: "/api/EmployeeAPI/GetAllState",
        type: 'get',
        dataType: "json",
        contentType: 'application/json',
        async: false,
        success: function (res) {
            if (res.IsSuccess) {
                $.each(res.data, function (i) {
                    var div_data = "<option value=" + res.data[i].StateId + ">" + res.data[i].StateName + "</option>";
                    $(div_data).appendTo('#StateId');
                    $(div_data).appendTo('#EStateId');
                });
            }
        },
        error: function (err) {
            console.log(err);
        }

    });
}
